package xyz.keklabor.music;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CatMusicPlayer {

    private final JavaPlugin plugin;
    private final Map<UUID, BukkitRunnable> musicTasks = new HashMap<>();
    private static final long CAT_DURATION_TICKS = 185 * 20; // ca. 185 Sekunden

    public CatMusicPlayer(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void startForPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (musicTasks.containsKey(uuid)) return;

        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                Location loc = new Location(Bukkit.getWorlds().get(0), 0, 64, 0);
                if (player.isOnline()) {
                    player.playSound(loc, Sound.MUSIC_DISC_CAT, SoundCategory.RECORDS, 100.0f, 1.0f);
                } else {
                    cancel();
                }
            }
        };

        task.runTaskTimer(plugin, 0L, CAT_DURATION_TICKS);
        musicTasks.put(uuid, task);
    }

    public void stopForPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (musicTasks.containsKey(uuid)) {
            musicTasks.get(uuid).cancel();
            musicTasks.remove(uuid);
        }
    }

    public boolean isPlayingForPlayer(Player player) {
        return musicTasks.containsKey(player.getUniqueId());
    }

    public void stopAll() {
        for (BukkitRunnable task : musicTasks.values()) {
            task.cancel();
        }
        musicTasks.clear();
    }
}
