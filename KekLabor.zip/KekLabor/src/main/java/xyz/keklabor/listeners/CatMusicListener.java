package xyz.keklabor.listeners;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.keklabor.music.CatMusicPlayer;

public class CatMusicListener implements Listener {

    private final CatMusicPlayer catMusicPlayer;
    private final JavaPlugin plugin;

    public CatMusicListener(CatMusicPlayer catMusicPlayer, JavaPlugin plugin) {
        this.catMusicPlayer = catMusicPlayer;
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if (!catMusicPlayer.isPlayingForPlayer(player)) {
            catMusicPlayer.startForPlayer(player);
            plugin.getLogger().info("Musik-Loop für " + player.getName() + " gestartet.");
        } else {
            plugin.getLogger().info("Musik läuft bereits für " + player.getName());
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        catMusicPlayer.stopForPlayer(event.getPlayer());
        plugin.getLogger().info("Musik-Loop für " + event.getPlayer().getName() + " gestoppt (Spieler hat verlassen).");
    }
}
