package xyz.keklabor.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import xyz.keklabor.music.CatMusicPlayer;

public class MusicCommand implements CommandExecutor {

    private final CatMusicPlayer catMusicPlayer;

    public MusicCommand(CatMusicPlayer catMusicPlayer) {
        this.catMusicPlayer = catMusicPlayer;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player player) {
            if (catMusicPlayer.isPlayingForPlayer(player)) {
                player.sendMessage("🎶 Musik läuft gerade!");
            } else {
                player.sendMessage("🔇 Keine Musik aktiv.");
            }
        }
        return true;
    }
}
