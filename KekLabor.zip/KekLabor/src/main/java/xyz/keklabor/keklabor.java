package xyz.keklabor;

import org.bukkit.plugin.java.JavaPlugin;
import xyz.keklabor.commands.SpawnCommand;
import xyz.keklabor.listeners.CatMusicListener;
import xyz.keklabor.music.CatMusicPlayer;

import java.util.Objects;

public class keklabor extends JavaPlugin {

    private CatMusicPlayer catMusicPlayer;

    @Override
    public void onEnable() {
        registerEvents();
        registerCommands();


        catMusicPlayer = new CatMusicPlayer(this);
        getServer().getPluginManager().registerEvents(new CatMusicListener(catMusicPlayer, this), this);


        getLogger().info("KekLabor - SpawnMusicPlayer Enabled");

    }

    @Override
    public void onDisable() {
      catMusicPlayer.stopAll();
      getLogger().info("KekLabor - SpawnMusicPlayer Disabled");

    }

    private void registerCommands() {
        Objects.requireNonNull(getCommand("Spawn")).setExecutor(new SpawnCommand());

    }

    private void registerEvents() {


    }
}
